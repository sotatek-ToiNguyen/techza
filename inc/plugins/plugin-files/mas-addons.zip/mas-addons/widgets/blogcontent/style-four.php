<div class="techza-blog-wrap">

    <div class="techza-blog-thumbnail">
        <?php if (has_post_thumbnail()) : ?>
            <a href="<?php echo esc_url(get_the_permalink()); ?>" class="post-link">
                <?php the_post_thumbnail('full'); ?>
            </a>
        <?php endif; ?>
    </div>


    <div class="techza-post-content">
        <div class="techza-post-meta">
        	<div class="techza-author-data">
	            <h5>
	                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	                    <path d="M6 5V1M14 5V1M5 9H15M3 19H17C18.1046 19 19 18.1046 19 17V5C19 3.89543 18.1046 3 17 3H3C1.89543 3 1 3.89543 1 5V17C1 18.1046 1.89543 19 3 19Z" stroke="#343E5F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
	                </svg>

	                <?php echo get_the_date(); ?>
	            </h5>
	        </div>
            <div class="techza-author-data">
	            <h5>
	                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M10 6.33333V10L12.75 12.75M18.25 10C18.25 14.5563 14.5563 18.25 10 18.25C5.44365 18.25 1.75 14.5563 1.75 10C1.75 5.44365 5.44365 1.75 10 1.75C14.5563 1.75 18.25 5.44365 18.25 10Z" stroke="#343E5F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>

	                <?php echo get_the_time(); ?>
	            </h5>
	        </div>

	        

        </div>
        <?php printf('<a href="%s" ><h3 class="techza-post-title">%s</h3></a>', get_the_permalink(), esc_html($title));
        echo 'yes' == $settings['show_excerpt'] ? sprintf('<p> %s </p>', esc_html($excerpt)) : ''; ?>

        

        <?php if ('yes' == $settings['show_readmore']) : ?>
            <div class="techza-post-btn-wrap">
                <a class='techza-post-btn' href="<?php the_permalink() ?>">
                    <?php if ('before' == $settings['icon_position'] && !empty($settings['btn_icon']['value'])) : ?>
                        <span class="icon-before btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['btn_icon'], ['aria-hidden' => 'true']) ?></span>
                    <?php endif; ?>
                    <span class="content"><?php echo esc_html($settings['readmore_text']); ?></span>
                    <?php if ('after' == $settings['icon_position'] && !empty($settings['btn_icon']['value'])) : ?>
                        <span class="icon-after btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['btn_icon'], ['aria-hidden' => 'true']) ?></span>
                    <?php endif; ?>
                </a>
            </div>
        <?php endif; ?>
    </div>


</div>