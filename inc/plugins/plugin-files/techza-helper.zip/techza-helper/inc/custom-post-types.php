<?php
// File Security Check
if (!defined('ABSPATH')) {
	exit;
}
class TechzaCustomPosts
{
	function __construct()
	{
		add_action('admin_menu', array($this, 'techza_header_footer_menu'));
		// Header
		add_action('init', array($this, 'techza_header'));
		add_action('init', array($this, 'techza_footer'));

		if(techza_check_cpt('megamenu')){
			add_action('init', array($this, 'techza_megamenu'));
		}

		// Portfolios
		if (techza_check_cpt('portfolio')) {
			add_action('init', array($this, 'techza_portfolio'));
			add_action('init', array($this, 'techza_portfolio_category'));
			add_action('init', array($this, 'techza_portfolio_tags'));
		}


		// team
		if (techza_check_cpt('team')) {
			add_action('init', array($this, 'techza_team'));
		}

		// services
		if (techza_check_cpt('service')) {
			add_action('init', array($this, 'techza_service'));
			add_action('init', array($this, 'techza_service_category'));
			add_action('init', array($this, 'techza_service_tags'));
		}

		// crypto
		// if (techza_check_cpt('crypto')) {
		// 	add_action('init', array($this, 'techza_crypto'));
		// 	add_action('init', array($this, 'techza_crypto_category'));
		// 	add_action('init', array($this, 'techza_crypto_tags'));
		// }

		
		// job
		if (techza_check_cpt('job')) {
			add_action('init', array($this, 'techza_job'));
			add_action('init', array($this, 'techza_job_category'));
			add_action('init', array($this, 'techza_job_tags'));
			add_action('init', array($this, 'techza_job_location'));
		}

		// Testimonial
		// if (techza_check_cpt('testimonial')) {
		// 	add_action('init', array($this, 'techza_testimonial'));
		// }


		// Case Study
		if (techza_check_cpt('case-study')) {
			add_action('init', array($this, 'techza_case_study'));
			add_action('init', array($this, 'techza_case_study_category'));
			add_action('init', array($this, 'techza_case_study_tags'));
		}
	}

	public function techza_header_footer_menu()
	{
		add_menu_page(
			'Header & Footer',
			'Header & Footer',
			'read',
			'header-footer',
			'',
			'dashicons-archive',
			40
		);
	}
	/**
	 *
	 * Techza Header Footer Post Type
	 *
	 */
	public function techza_header()
	{
		$labels = array(
			'name'               => _x('Header', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Header', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Header', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Header', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Header', 'techza-hp'),
			'add_new_item'       => __('Add New Header', 'techza-hp'),
			'new_item'           => __('New Header', 'techza-hp'),
			'edit_item'          => __('Edit Header', 'techza-hp'),
			'view_item'          => __('View Header', 'techza-hp'),
			'all_items'          => __('All Headers', 'techza-hp'),
			'search_items'       => __('Search Headers', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Headers found.', 'techza-hp'),
			'not_found_in_trash' => __('No Headers found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'show_in_menu' 		 => 'header-footer',
			'rewrite'            => array('slug' => 'header'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('techza_header', $args);
	}

	public function techza_footer()
	{
		$labels = array(
			'name'               => _x('Footer', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Footer', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Footer', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Footer', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Footer', 'techza-hp'),
			'add_new_item'       => __('Add New Footer', 'techza-hp'),
			'new_item'           => __('New Footer', 'techza-hp'),
			'edit_item'          => __('Edit Footer', 'techza-hp'),
			'view_item'          => __('View Footer', 'techza-hp'),
			'all_items'          => __('All Footers', 'techza-hp'),
			'search_items'       => __('Search Footers', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Footers found.', 'techza-hp'),
			'not_found_in_trash' => __('No Footers found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'footer'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'show_in_menu' 		 => 'header-footer',
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('techza_footer', $args);
	}


	public function techza_megamenu()
	{
		$labels = array(
			'name'               => _x('Mega Menu', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Mega Menu', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Mega Menu', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Mega Menu', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Mega Menu', 'techza-hp'),
			'add_new_item'       => __('Add New Mega Menu', 'techza-hp'),
			'new_item'           => __('New Mega Menu', 'techza-hp'),
			'edit_item'          => __('Edit Mega Menu', 'techza-hp'),
			'view_item'          => __('View Mega Menu', 'techza-hp'),
			'all_items'          => __('All Mega Menus', 'techza-hp'),
			'search_items'       => __('Search Mega Menus', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Mega Menus found.', 'techza-hp'),
			'not_found_in_trash' => __('No Mega Menus found in Trash.', 'techza-hp')
		);

		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'megamenu'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			// 'show_in_menu' 		 => 'header-footer',
			'supports'           => array('title', 'elementor', 'thumbnail',  'page-attributes')
		);
		register_post_type('techza_megamenu', $args);
	}

	/**
	 *
	 * techza Service Custom Post Type
	 *
	 */
	public function techza_service()
	{
		$labels = array(
			'name'               => _x('Service', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Service', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Service', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Service', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Service', 'techza-hp'),
			'add_new_item'       => __('Add New Service', 'techza-hp'),
			'new_item'           => __('New Service', 'techza-hp'),
			'edit_item'          => __('Edit Service', 'techza-hp'),
			'view_item'          => __('View Service', 'techza-hp'),
			'all_items'          => __('All Services', 'techza-hp'),
			'search_items'       => __('Search Services', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Services found.', 'techza-hp'),
			'not_found_in_trash' => __('No Services found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-megaphone',
			'rewrite'            => array('slug' => 'service', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('service', $args);
	}
	public function techza_service_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Categories', 'techza-hp'),
			'all_items'         => __('All Categories', 'techza-hp'),
			'parent_item'       => __('Parent Category', 'techza-hp'),
			'parent_item_colon' => __('Parent Category:', 'techza-hp'),
			'edit_item'         => __('Edit Category', 'techza-hp'),
			'update_item'       => __('Update Category', 'techza-hp'),
			'add_new_item'      => __('Add New Category', 'techza-hp'),
			'new_item_name'     => __('New Category Name', 'techza-hp'),
			'menu_name'         => __('Category', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'service-category'),
		);
		register_taxonomy('service-category', array('service'), $args);
	}
	public function techza_service_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Tags', 'techza-hp'),
			'all_items'         => __('All Tags', 'techza-hp'),
			'parent_item'       => __('Parent Tag', 'techza-hp'),
			'parent_item_colon' => __('Parent Tag:', 'techza-hp'),
			'edit_item'         => __('Edit Tag', 'techza-hp'),
			'update_item'       => __('Update Tag', 'techza-hp'),
			'add_new_item'      => __('Add New Tag', 'techza-hp'),
			'new_item_name'     => __('New Tag Name', 'techza-hp'),
			'menu_name'         => __('Tag', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'pf-tag'),
		);
		register_taxonomy('service-tag', array('service'), $args);
	}


	/**
	 *
	 * techza Cripto Custom Post Type
	 *
	 */
	public function techza_crypto()
	{
		$labels = array(
			'name'               => _x('Crypto', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Crypto', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Crypto', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Crypto', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Crypto', 'techza-hp'),
			'add_new_item'       => __('Add New Crypto', 'techza-hp'),
			'new_item'           => __('New Crypto', 'techza-hp'),
			'edit_item'          => __('Edit Crypto', 'techza-hp'),
			'view_item'          => __('View Crypto', 'techza-hp'),
			'all_items'          => __('All Cryptos', 'techza-hp'),
			'search_items'       => __('Search Cryptos', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Cryptos found.', 'techza-hp'),
			'not_found_in_trash' => __('No Cryptos found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-money-alt',
			'rewrite'            => array('slug' => 'crypto', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('crypto', $args);
	}
	public function techza_crypto_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Categories', 'techza-hp'),
			'all_items'         => __('All Categories', 'techza-hp'),
			'parent_item'       => __('Parent Category', 'techza-hp'),
			'parent_item_colon' => __('Parent Category:', 'techza-hp'),
			'edit_item'         => __('Edit Category', 'techza-hp'),
			'update_item'       => __('Update Category', 'techza-hp'),
			'add_new_item'      => __('Add New Category', 'techza-hp'),
			'new_item_name'     => __('New Category Name', 'techza-hp'),
			'menu_name'         => __('Category', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'crypto-category'),
		);
		register_taxonomy('crypto-category', array('crypto'), $args);
	}
	public function techza_crypto_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Tags', 'techza-hp'),
			'all_items'         => __('All Tags', 'techza-hp'),
			'parent_item'       => __('Parent Tag', 'techza-hp'),
			'parent_item_colon' => __('Parent Tag:', 'techza-hp'),
			'edit_item'         => __('Edit Tag', 'techza-hp'),
			'update_item'       => __('Update Tag', 'techza-hp'),
			'add_new_item'      => __('Add New Tag', 'techza-hp'),
			'new_item_name'     => __('New Tag Name', 'techza-hp'),
			'menu_name'         => __('Tag', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'crypto-tag'),
		);
		register_taxonomy('crypto-tag', array('crypto'), $args);
	}

	/**
	 *
	 * Techza Team Post Type
	 *
	 */
	public function techza_team()
	{
		$labels = array(
			'name'               => _x('Team Member', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Team Member', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Team Member', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Team Member', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Member', 'techza-hp'),
			'add_new_item'       => __('Add New Member', 'techza-hp'),
			'new_item'           => __('New Member', 'techza-hp'),
			'edit_item'          => __('Edit Member', 'techza-hp'),
			'view_item'          => __('View Member', 'techza-hp'),
			'all_items'          => __('All Team Members', 'techza-hp'),
			'search_items'       => __('Search Team Members', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Team Members found.', 'techza-hp'),
			'not_found_in_trash' => __('No Team Members found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'team', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail', 'elementor',  'page-attributes')
		);
		register_post_type('team', $args);
	}

	/**
	 *
	 * Techza Portfolio Post Type
	 *
	 */
	public function techza_portfolio()
	{
		$labels = array(
			'name'               => _x('Portfolio', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Portfolio', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Portfolio', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Portfolio', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Portfolio', 'techza-hp'),
			'add_new_item'       => __('Add New Portfolio', 'techza-hp'),
			'new_item'           => __('New Portfolio', 'techza-hp'),
			'edit_item'          => __('Edit Portfolio', 'techza-hp'),
			'view_item'          => __('View Portfolio', 'techza-hp'),
			'all_items'          => __('All Portfolios', 'techza-hp'),
			'search_items'       => __('Search Portfolios', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Portfolios found.', 'techza-hp'),
			'not_found_in_trash' => __('No Portfolios found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'portfolio', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('portfolio', $args);
	}
	public function techza_portfolio_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Categories', 'techza-hp'),
			'all_items'         => __('All Categories', 'techza-hp'),
			'parent_item'       => __('Parent Category', 'techza-hp'),
			'parent_item_colon' => __('Parent Category:', 'techza-hp'),
			'edit_item'         => __('Edit Category', 'techza-hp'),
			'update_item'       => __('Update Category', 'techza-hp'),
			'add_new_item'      => __('Add New Category', 'techza-hp'),
			'new_item_name'     => __('New Category Name', 'techza-hp'),
			'menu_name'         => __('Category', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-category'),
		);
		register_taxonomy('portfolio-category', array('portfolio'), $args);
	}
	public function techza_portfolio_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Tags', 'techza-hp'),
			'all_items'         => __('All Tags', 'techza-hp'),
			'parent_item'       => __('Parent Tag', 'techza-hp'),
			'parent_item_colon' => __('Parent Tag:', 'techza-hp'),
			'edit_item'         => __('Edit Tag', 'techza-hp'),
			'update_item'       => __('Update Tag', 'techza-hp'),
			'add_new_item'      => __('Add New Tag', 'techza-hp'),
			'new_item_name'     => __('New Tag Name', 'techza-hp'),
			'menu_name'         => __('Tag', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-tag'),
		);
		register_taxonomy('portfolio-tag', array('portfolio'), $args);
	}

	/**
	 *
	 * Techza Job Post Type
	 *
	 */
	public function techza_job()
	{
		$labels = array(
			'name'               => _x('Job', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Job', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Job', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Job', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Job', 'techza-hp'),
			'add_new_item'       => __('Add New Job', 'techza-hp'),
			'new_item'           => __('New Job', 'techza-hp'),
			'edit_item'          => __('Edit Job', 'techza-hp'),
			'view_item'          => __('View Job', 'techza-hp'),
			'all_items'          => __('All Jobs', 'techza-hp'),
			'search_items'       => __('Search Jobs', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Jobs found.', 'techza-hp'),
			'not_found_in_trash' => __('No Jobs found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'job', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('job', $args);
	}
	public function techza_job_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Categories', 'techza-hp'),
			'all_items'         => __('All Categories', 'techza-hp'),
			'parent_item'       => __('Parent Category', 'techza-hp'),
			'parent_item_colon' => __('Parent Category:', 'techza-hp'),
			'edit_item'         => __('Edit Category', 'techza-hp'),
			'update_item'       => __('Update Category', 'techza-hp'),
			'add_new_item'      => __('Add New Category', 'techza-hp'),
			'new_item_name'     => __('New Category Name', 'techza-hp'),
			'menu_name'         => __('Category', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-category'),
		);
		register_taxonomy('job-category', array('job'), $args);
	}
	public function techza_job_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Tags', 'techza-hp'),
			'all_items'         => __('All Tags', 'techza-hp'),
			'parent_item'       => __('Parent Tag', 'techza-hp'),
			'parent_item_colon' => __('Parent Tag:', 'techza-hp'),
			'edit_item'         => __('Edit Tag', 'techza-hp'),
			'update_item'       => __('Update Tag', 'techza-hp'),
			'add_new_item'      => __('Add New Tag', 'techza-hp'),
			'new_item_name'     => __('New Tag Name', 'techza-hp'),
			'menu_name'         => __('Tag', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-tag'),
		);
		register_taxonomy('job-tag', array('job'), $args);
	}
	public function techza_job_location()
	{
		$labels = array(
			'name'              => _x('Job Locations', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Job Location', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Job Locations', 'shadepro-ts'),
			'all_items'         => __('All Job Locations', 'shadepro-ts'),
			'parent_item'       => __('Parent Job Location', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Job Location:', 'shadepro-ts'),
			'edit_item'         => __('Edit Job Location', 'shadepro-ts'),
			'update_item'       => __('Update Job Location', 'shadepro-ts'),
			'add_new_item'      => __('Add New Job Location', 'shadepro-ts'),
			'new_item_name'     => __('New Job Location Name', 'shadepro-ts'),
			'menu_name'         => __('Job Location', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-location'),
		);
		register_taxonomy('job-location', array('job'), $args);
	}
	//Testimonial
	public function techza_testimonial()
	{
		$labels = array(
			'name'               => _x('Testimonial', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Testimonial', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Testimonial', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Testimonial', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Testimonial', 'techza-hp'),
			'add_new_item'       => __('Add New Testimonial', 'techza-hp'),
			'new_item'           => __('New Testimonial', 'techza-hp'),
			'edit_item'          => __('Edit Testimonial', 'techza-hp'),
			'view_item'          => __('View Testimonial', 'techza-hp'),
			'all_items'          => __('All Testimonial', 'techza-hp'),
			'search_items'       => __('Search Testimonial', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Testimonial found.', 'techza-hp'),
			'not_found_in_trash' => __('No Testimonial found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-testimonial',
			'rewrite'            => array('slug' => 'techza_testimonial', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('techza_testimonial', $args);
	}
	public function techza_testimonial_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Categories', 'techza-hp'),
			'all_items'         => __('All Categories', 'techza-hp'),
			'parent_item'       => __('Parent Category', 'techza-hp'),
			'parent_item_colon' => __('Parent Category:', 'techza-hp'),
			'edit_item'         => __('Edit Category', 'techza-hp'),
			'update_item'       => __('Update Category', 'techza-hp'),
			'add_new_item'      => __('Add New Category', 'techza-hp'),
			'new_item_name'     => __('New Category Name', 'techza-hp'),
			'menu_name'         => __('Category', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-category'),
		);
		register_taxonomy('testimonial_category', array('techza_testimonial'), $args);
	}
	public function techza_testimonial_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Tags', 'techza-hp'),
			'all_items'         => __('All Tags', 'techza-hp'),
			'parent_item'       => __('Parent Tag', 'techza-hp'),
			'parent_item_colon' => __('Parent Tag:', 'techza-hp'),
			'edit_item'         => __('Edit Tag', 'techza-hp'),
			'update_item'       => __('Update Tag', 'techza-hp'),
			'add_new_item'      => __('Add New Tag', 'techza-hp'),
			'new_item_name'     => __('New Tag Name', 'techza-hp'),
			'menu_name'         => __('Tag', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-tag'),
		);
		register_taxonomy('testimonial_tag', array('techza_testimonial'), $args);
	}

	//Case Study

	public function techza_case_study()
	{
		$labels = array(
			'name'               => _x('Case Study', 'post type general name', 'techza-hp'),
			'singular_name'      => _x('Case Study', 'post type singular name', 'techza-hp'),
			'menu_name'          => _x('Case Study', 'admin menu', 'techza-hp'),
			'name_admin_bar'     => _x('Case Study', 'add new on admin bar', 'techza-hp'),
			'add_new'            => __('Add New Studies', 'techza-hp'),
			'add_new_item'       => __('Add New Studies', 'techza-hp'),
			'new_item'           => __('New Studies', 'techza-hp'),
			'edit_item'          => __('Edit Studies', 'techza-hp'),
			'view_item'          => __('View Studies', 'techza-hp'),
			'all_items'          => __('All Studies', 'techza-hp'),
			'search_items'       => __('Search Studies', 'techza-hp'),
			'parent_item_colon'  => __('Parent :', 'techza-hp'),
			'not_found'          => __('No Studies found.', 'techza-hp'),
			'not_found_in_trash' => __('No Studies found in Trash.', 'techza-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'techza-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-media-spreadsheet',
			'rewrite'            => array('slug' => 'case-studies', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'excerpt', 'thumbnail',  'page-attributes')
		);
		register_post_type('case-study', $args);
	}

	public function techza_case_study_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Categories', 'techza-hp'),
			'all_items'         => __('All Categories', 'techza-hp'),
			'parent_item'       => __('Parent Category', 'techza-hp'),
			'parent_item_colon' => __('Parent Category:', 'techza-hp'),
			'edit_item'         => __('Edit Category', 'techza-hp'),
			'update_item'       => __('Update Category', 'techza-hp'),
			'add_new_item'      => __('Add New Category', 'techza-hp'),
			'new_item_name'     => __('New Category Name', 'techza-hp'),
			'menu_name'         => __('Category', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'studies_category'),
		);
		register_taxonomy('case-study-category', array('case-study'), $args);
	}

	public function techza_case_study_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'techza-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'techza-hp'),
			'search_items'      => __('Search Tags', 'techza-hp'),
			'all_items'         => __('All Tags', 'techza-hp'),
			'parent_item'       => __('Parent Tag', 'techza-hp'),
			'parent_item_colon' => __('Parent Tag:', 'techza-hp'),
			'edit_item'         => __('Edit Tag', 'techza-hp'),
			'update_item'       => __('Update Tag', 'techza-hp'),
			'add_new_item'      => __('Add New Tag', 'techza-hp'),
			'new_item_name'     => __('New Tag Name', 'techza-hp'),
			'menu_name'         => __('Tag', 'techza-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'studies-tag'),
		);
		register_taxonomy('studies-tag', array('case-study'), $args);
	}
}
$techzaCcases_stydyInstance = new TechzaCustomPosts;
