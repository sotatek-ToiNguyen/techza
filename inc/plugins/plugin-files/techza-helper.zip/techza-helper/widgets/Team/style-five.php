	<div class="team-single-item">
		<div class="team-thumb">
			<a  href="<?php the_permalink(); ?>">
		        <?php if(has_post_thumbnail() ): ?>
		            <div class="team-image">
		                <?php the_post_thumbnail('full');?>
		            </div>
		        <?php endif; ?>
		    </a>
		    <?php if (function_exists('the_field')  && 'yes' == $settings['show_socail_links'] ):
	            $social_links = get_field('social_links');
	            ?>
	        <?php endif;?>
	         <div class="social-icons">
		        <ul>
		            <?php foreach( $social_links as  $social_link):  ?>
		            <li>
		                <a href="<?php echo esc_url($social_link['url']); ?>">
		                <?php echo $social_link['icon'] ?>
		                </a>
		            </li>
		            <?php endforeach; ?>
		        </ul>
		    </div>
		</div>
	    
		<div class="user-identity">
			<a href="<?php the_permalink(); ?>">
				<h6><?php the_title();?></h6>
				<?php if (function_exists('the_field')): ?>
	            	<span><?php the_field('position')?></span>
	        	<?php endif;?>
			</a>
	        <?php if (function_exists('the_field')  && 'yes' == $settings['show_socail_links'] ):
	            $social_links = get_field('social_links');
	            ?>
	        <?php endif;?>
	    </div>
	    	
	</div>
