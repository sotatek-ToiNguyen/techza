<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Techza_Testimonial_Normal extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Techza_Testimonial_Normal';
	}

	public function get_title() {
		return esc_html__( 'Techza Testimonial Normal', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'testimonial', 'normal', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

    	$this->add_control(
            'star',
            [
                'label'     => __( 'Customar Rating', 'masco' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => '5',
                'options'   => [
                    'none' => __( 'none', 'masco' ),
                    '1'    => __( '1', 'masco' ),
                    '2'    => __( '2', 'masco' ),
                    '3'    => __( '3', 'masco' ),
                    '4'    => __( '4', 'masco' ),
                    '5'    => __( '5', 'masco' ),
                ],
             
            ]
        );

    	$this->add_control(
			'techza_t_title',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Great experience and great cashback', 'masco-hp' ),
				'placeholder' => esc_html__( 'Great experience and great cashback', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'techza_t_description',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( '“Excellent IT service provider. The team contacted me quickly and dealt with my issue promptly & professionally. I can highly recommend this company.”', 'masco-hp' ),
				'label_block' => true
			]
		);


		$this->add_control(
			'techza_t_author_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		
	
		$this->add_control(
			'techza_t_author_name',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Great experience and great cashback', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'techza_t_author_designation',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Founder @ Company', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);


		$this->end_controls_section();


		// Image
		$this->start_controls_section(
			'techza_t_author_thumb_style',
			[
				'label' => esc_html__( 'Image', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			't_author_thumb_width',
			[
				'label' => esc_html__( 'Width', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			't_author_thumb_height_width',
			[
				'label' => esc_html__( 'Height', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 't_author_thumb_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author img',
			]
		);

		$this->add_responsive_control(
			't_author_thumb_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);
		$this->add_responsive_control(
			't_author_thumb_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// end image style

		//Rating
        $this->start_controls_section(
            'rating_style',
            [
                'label'     => __( 'Stars', 'masco' ),
                'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
             
            ]
        );
        $this->add_control(
            'star_size',
            [
                'label'      => __( 'Size', 'masco' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .techza-testimonial-star i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'star_gap',
            [
                'label'      => __( 'Spacing', 'masco' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .techza-testimonial-star i' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'star_color',
            [
                'label'     => __( 'Icon Color', 'masco' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#F0AD4Es',
                'selectors' => [
                    '{{WRAPPER}} .techza-testimonial-star i' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'star_margin',
            [
                'label'      => __( 'Margin', 'masco' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .techza-testimonial-star' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();



		// Title 
		$this->start_controls_section(
			't_title_style',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_title_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data h5' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_title_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data h5',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_title_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data h5',
			]
		);

		$this->add_control(
			't_title_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End Description style

	

		// Description 
		$this->start_controls_section(
			't_des_style',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_des_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_des_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data p',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_des_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data p',
			]
		);

		$this->add_control(
			't_des_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End Description style

		//  author 
		$this->start_controls_section(
			't_author_style',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data h6' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data h6',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data h6',
			]
		);

		$this->add_control(
			't_author_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data h6' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style

		// star  author  Designation
		$this->start_controls_section(
			't_author_designation_style',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_designation_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_designation_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data span',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_designation_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data span',
			]
		);

		$this->add_control(
			't_author_designation_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style


		//  box 
		$this->start_controls_section(
			't_box_style',
			[
				'label' => esc_html__( 'Box', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'box_t_style_tabs'
		);

		$this->start_controls_tab(
			'box_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'techza-hp' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 't_box_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 't_box_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap',
			]
		);

		$this->add_control(
			't_box_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 't_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap',
			]
		);

		$this->add_responsive_control(
			't_box_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		// box hover

		$this->start_controls_tab(
			'box_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'techza-hp' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'hover_t_box_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap:hover',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'hover_t_box_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap:hover',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'hover_t_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap:hover',
			]
		);


		$this->end_controls_tabs();
		$this->end_controls_section();
		// End box style




		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$star = $settings['star'];
		$techza_t_title = $settings['techza_t_title'];
		$techza_t_description = $settings['techza_t_description'];
		$techza_t_author_thumb = $settings['techza_t_author_thumb'];
		$techza_t_author_name = $settings['techza_t_author_name'];
		$techza_t_author_designation = $settings['techza_t_author_designation'];

	?>
			     
          <div class="techza-t-infinite-slider-wrap">
          		<?php if ( 'none' != $star ): ?>
				<div class="techza-testimonial-star">
                    <?php for ( $i = 0; $i < $star; $i++ ): ?>
                        <i class="fa fa-star"></i>
                    <?php endfor;?>
                </div>
				<?php endif;?>
          	<div class="techza-t-infinite-slider-data">
          		<?php if ($techza_t_title): ?>
          			<h5><?php echo esc_html($techza_t_title); ?></h5>
          		<?php endif ?>
          		
          		<?php if ($techza_t_description): ?>
          			<p><?php echo esc_html($techza_t_description); ?></p>
          		<?php endif ?>

          	</div>
          	<div class="techza-t-infinite-slider-author-wrap">
          		<div class="techza-t-infinite-slider-author">
          			<?php if ($techza_t_author_thumb): ?>
          				<img src="<?php echo esc_url($techza_t_author_thumb['url']); ?>" alt="">
          			<?php endif ?>
          			
          		</div>
          		<div class="techza-t-infinite-slider-author-data">
          			<?php if ($techza_t_author_name): ?>
          				<h6><?php echo esc_html($techza_t_author_name); ?></h6>
          			<?php endif ?>

          			<?php if ($techza_t_author_designation): ?>
          				<span><?php echo esc_html($techza_t_author_designation); ?></span>
          			<?php endif ?>
          			
          			
          		</div>
          	</div>
          </div>
						





	<?php
   
 }

}

$widgets_manager->register( new \Techza_Testimonial_Normal() );