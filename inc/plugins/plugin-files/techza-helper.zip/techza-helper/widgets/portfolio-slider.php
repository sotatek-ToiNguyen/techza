<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Techza_portfolio_slider_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Techza_Portfolio_Slider';
	}

	public function get_title() {
		return esc_html__( 'Techza Portfolio Slider', 'techza-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'techza-addons' ];
	}

	public function get_keywords() {
		return [ 'text', 'animate', 'portfolio', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


 	$this->add_responsive_control(
            'content_align',
            [
                'label' => __( 'Alignment', 'techza-hp' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'techza-hp' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'techza-hp' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'techza-hp' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .techza-portfolio-data' => 'text-align: {{VALUE}};',
                ],
            ]
        );

    $repeater = new \Elementor\Repeater();


    	$repeater->add_control(
			'techza_p_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'techza_p_title',
			[
				'label' => esc_html__( 'Title', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'title', 'techza-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'techza-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'techza_p_dagination',
			[
				'label' => esc_html__( 'Dagination', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Web Development', 'techza-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'techza-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'techza_p_slider_list',
			[
				'label' => esc_html__( 'Repeater List', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'techza_p_thumb' => esc_html__( 'Image', 'techza-hp' ),
						'techza_p_title' => esc_html__( 'CMS best software solutions', 'techza-hp' ),
						'techza_p_dagination' => esc_html__( 'Web Development', 'techza-hp' ),
					],
				
				],
			]
		);


		$this->end_controls_section();

		// slider arrow

		$this->start_controls_section(
			'slider_content_section',
			[
				'label' => esc_html__( 'Arrows', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'p_arrow_prev_icon',
			[
				'label' => esc_html__( 'Slider Icon Left', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'p_arrow_next_icon',
			[
				'label' => esc_html__( 'Slider Icon Right', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->end_controls_section();

		// slider Setting

		$this->start_controls_section(
			'slider_setting_section',
			[
				'label' => esc_html__( 'Setting', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
					'label' => __('Auto Play?', 'techza-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'techza-hp'),
					'label_off' => __('Hide', 'techza-hp'),
					'return_value' => 'yes',
					'default' => 'yes',
			]
		);
		$this->add_control(
			'arrows',
			[
					'label' => __('Show arrows?', 'techza-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'techza-hp'),
					'label_off' => __('Hide', 'techza-hp'),
					'return_value' => 'yes',
					'default' => 'yes',
			]
		);



		$this->end_controls_section();

		// start style parts

		
		// Image
		$this->start_controls_section(
			'techza_p_thumb_style',
			[
				'label' => esc_html__( 'Image', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'p_thumb_width',
			[
				'label' => esc_html__( 'Width', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-thumb img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'p_thumb_height',
			[
				'label' => esc_html__( 'Height', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-thumb img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'p_thumb_border',
				'label' => esc_html__( 'Border', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-portfolio-thumb img',
			]
		);

		$this->add_responsive_control(
			'p_thumb_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);
		$this->add_responsive_control(
			'p_thumb_margin',
			[
				'label' => esc_html__( 'Margin', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// end image style


			// Title
		$this->start_controls_section(
			'p_title_style',
			[
				'label' => esc_html__( 'Title', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'p_title_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-data h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_title_typography',
				'selector' => '{{WRAPPER}} .techza-portfolio-data h3',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'p_title_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-portfolio-data h3',
			]
		);

		$this->add_control(
			'p_title_margin',
			[
				'label' => esc_html__( 'Margin', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-data h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End title style

		// dagination 
		$this->start_controls_section(
			'p_dagination_style',
			[
				'label' => esc_html__( 'Dagination', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'dagination_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-data p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_dagination_typography',
				'selector' => '{{WRAPPER}} .techza-portfolio-data p',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'p_dagination_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-portfolio-data p',
			]
		);

		$this->add_control(
			'p_dagination_margin',
			[
				'label' => esc_html__( 'Margin', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-data p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End title style


		// Content box 
		$this->start_controls_section(
			'p_content_box_style',
			[
				'label' => esc_html__( 'Content Box', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
            'p_content_box_background',
            [
                'label'     => __('Background', 'techza-hp'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techza-portfolio-data' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'p_content_box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-data' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'p_content_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-portfolio-data',
			]
		);

		$this->add_responsive_control(
			'p_content_box_padding',
			[
				'label' => esc_html__( 'Padding', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-portfolio-data' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End title style


		// slider arrows
		$this->start_controls_section(
			'icon_style_section',
			[
				'label' => esc_html__( 'Arrows', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'arrows_style_tabs'
		);

		$this->start_controls_tab(
			'arrow_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'techza-hp' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrow_background',
				'label' => esc_html__( 'Background', 'techza-hp' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .portfolio-slider-arrows button',
			]
		);

		$this->add_control(
			'arrow_fill_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .portfolio-slider-arrows button path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_width',
			[
				'label' => esc_html__( 'Width', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				
				],
		
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			'arrows_height',
			[
				'label' => esc_html__( 'Height', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				
				],
		
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button' => 'height: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'arrows_size',
			[
				'label' => esc_html__( 'Size', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .portfolio-slider-arrows button svg' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'arrows_border_radius_border',
				'label' => esc_html__( 'Border', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .portfolio-slider-arrows button',
			]
		);

		$this->add_control(
			'arrows_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .portfolio-slider-arrows button',
			]
		);

		$this->end_controls_tab();

		// icon hover

		$this->start_controls_tab(
			'arrows_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'techza-hp' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrows_hover_background',
				'label' => esc_html__( 'Background', 'techza-hp' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .portfolio-slider-arrows button:hover',
			]
		);

		$this->add_control(
			'arrows_hover_fill_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .portfolio-slider-arrows button:hover path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrows_hover_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .portfolio-slider-arrows button:hover path' => 'stroke: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'arrows_border_radius_border_hover',
				'label' => esc_html__( 'Border', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .portfolio-slider-arrows button',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_hover_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .portfolio-slider-arrows button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();


		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$contents = $settings['techza_p_slider_list'];
		$p_arrow_prev_icon = $settings['p_arrow_prev_icon'];
		$p_arrow_next_icon = $settings['p_arrow_next_icon'];

		 //this code slider option
		 $slider_extraSetting = array(

			'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
			'arrows' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,

		);

		$jasondecode = wp_json_encode($slider_extraSetting);
	
			$this->add_render_attribute('techza_slider_active', 'class', array('techza-portfolio-slider', 't-style'));
			$this->add_render_attribute('techza_slider_active', 'data-settings', $jasondecode);

		?>

			<div class="techza-portfolio-slider-wrap">
				<div <?php echo $this->get_render_attribute_string('techza_slider_active'); ?>>
		            <?php foreach($contents as $content) : ?>
	                  <div class="techza-portfolio-wrap">
	                  	<div class="techza-portfolio-thumb">
	                  		<img src="<?php echo esc_url($content['techza_p_thumb']['url'])  ?>" alt="">
	                  		<div class="techza-portfolio-data">
		                  		<?php if($content['techza_p_title'] ): ?>
		                              <h3><?php echo esc_html($content['techza_p_title']);  ?></h3>
		                          <?php endif; ?>
		                          <?php if($content['techza_p_dagination'] ): ?>
		                              <p><?php echo esc_html($content['techza_p_dagination']); ?></p>
		                          <?php endif; ?>
		                  	</div>
	                  	</div>
	                  	
	                  </div>
		            <?php endforeach; ?>
				</div>
			</div>
			

		<div class="portfolio-slider-arrows">
			<?php if (!empty($settings['p_arrow_prev_icon']['value'])) : ?>
				<button type="button" class="slick-prev p-prev slick-arrow slick-active">
						<?php \Elementor\Icons_Manager::render_icon($p_arrow_prev_icon, ['aria-hidden' => 'true']);?>
				</button>
			<?php endif; ?>

			<?php if (!empty($settings['p_arrow_next_icon']['value'])) : ?>
				<button type="button" class="slick-next p-next slick-arrow ">
						<?php \Elementor\Icons_Manager::render_icon($p_arrow_next_icon, ['aria-hidden' => 'true']);?>
				</button>
			<?php endif; ?>
		</div>

		<?php
   
  }

}

$widgets_manager->register_widget_type( new \Techza_portfolio_slider_Widget() );