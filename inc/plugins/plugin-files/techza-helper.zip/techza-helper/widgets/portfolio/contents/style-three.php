<?php
if (!defined('ABSPATH')) {
    exit;
}
while ($the_query->have_posts()) : $the_query->the_post(); ?>
    <?php
    $idd = get_the_ID();
    $categories = get_the_terms($idd, 'portfolio-category');
    $grid = '';
    $image_height = ' height-' . get_post_meta($idd, 'image_height', true);
    $pf_cat_slug = '';

    $pf_cat_name = '';

    if (!empty($categories)) {
        $pf_cat_name = join(' ', wp_list_pluck($categories, 'name'));
        $pf_cat_slug = join(' ', wp_list_pluck($categories, 'slug'));
    }


   

    $cate_img = get_post_meta($idd, 'portfolio_category_image');
    
    $duration = get_post_meta($idd, 'duration', true);
    $mint_price = get_post_meta($idd, 'mint_price', true);

    
    
    if($active_slider == 'slider') {
        $grid = '';
    }elseif ('yes' == $settings['use_meta_grid']) {
        $grid =  'col-md-' . get_post_meta($idd, 'image_width', true);
    } else {
        $grid = $column_class;
    }

    ?>


    <div id="post-<?php the_ID(); ?>" class="<?php printf('techza-portfolio-item-wrap %s %s %s' , $grid  , $pf_cat_slug , $image_height); ?>">
        <a href="<?php the_permalink(); ?>" class="techza-portfolio-item <?php echo esc_attr($portfoli_verson) ?> ">
	        <div class="techza-portfolio-image d-block <?php echo esc_attr( 'elementor-animation-'.$settings['image_hover_animation'] ) ?>">
	            <?php the_post_thumbnail() ?>
	            <div class="techza-portfolio-content content-postion-on-image">
	                <?php if( 'yes' == $settings['show_title']): ?>
	                    <div class="techza-portfolio-title">
	                        <h3>
	                            <?php the_title(); ?>
	                        </h3>
	                    </div>
	                <?php endif; ?>
	                <?php  if (!empty($categories[0]->name) && 'yes' == $settings['show_category'] ) {
	                    echo '<span class="techza-pf-category">' . esc_html(($categories[0]->name)) . '</span>';
	                }?>
	                <?php if ( 'yes' == $settings['show_readmore'] ): ?>   
	                    <div class="portfolio-content-bottom">
	                        <div class="portfolio-btn-wrap">
	                            <button type="button" class="portfolio-btn <?php echo esc_attr( 'elementor-animation-' . $settings['btn_hover_animation'] ) ?>">
	                                <?php if ( 'before' == $settings['icon_position'] && !empty( $settings['icon']['value'] ) ): ?>
	                                <span
	                                    class="icon-before btn-icon"><?php \Elementor\Icons_Manager::render_icon( $settings['icon'], ['aria-hidden' => 'true'] )?></span>
	                                <?php endif;?>
	                                <?php echo esc_html( $settings['readmore_text'] ); ?>
	                                <?php if ( 'after' == $settings['icon_position'] && !empty( $settings['icon']['value'] ) ): ?>
	                                <span
	                                    class="icon-after btn-icon"><?php \Elementor\Icons_Manager::render_icon( $settings['icon'], ['aria-hidden' => 'true'] )?></span>
	                                <?php endif;?>
	                            </button>
	                        </div>
	                    </div>
	                <?php endif;?>
	            </div>
	        </div>
       </a>

    </div>

<!-- #post-<?php the_ID(); ?> -->
<?php
endwhile;
?>