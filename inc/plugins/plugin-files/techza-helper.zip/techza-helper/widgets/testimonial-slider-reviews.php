<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Techza_Testimonial_Infinite_slider extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Techza_Testimonial_Infinite_Slider';
	}

	public function get_title() {
		return esc_html__( 'Techza T Reviews Slider', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'testimonial', 'animate', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


    $repeater = new \Elementor\Repeater();

    	$repeater->add_control(
            'star',
            [
                'label'     => __( 'Customar Rating', 'masco' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => '5',
                'options'   => [
                    'none' => __( 'none', 'masco' ),
                    '1'    => __( '1', 'masco' ),
                    '2'    => __( '2', 'masco' ),
                    '3'    => __( '3', 'masco' ),
                    '4'    => __( '4', 'masco' ),
                    '5'    => __( '5', 'masco' ),
                ],
             
            ]
        );

    	$repeater->add_control(
			'techza_t_title',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Great experience and great cashback', 'masco-hp' ),
				'placeholder' => esc_html__( 'Great experience and great cashback', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'techza_t_description',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Masco is an excellent company. in everything uptime, fast technical support, sales, & billing-friendly people. If you want to open a web solutions must register.', 'masco-hp' ),
				'label_block' => true
			]
		);


		$repeater->add_control(
			'techza_t_author_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		
	
		$repeater->add_control(
			'techza_t_author_name',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Great experience and great cashback', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'techza_t_author_designation',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Founder @ Company', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'techza_t_list',
			[
				'label' => esc_html__( 'Repeater List', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'star' => esc_html__( 'Star', 'masco-hp' ),
						'techza_t_title' => esc_html__( 'Author Title', 'masco-hp' ),
						'techza_t_author_thumb' => esc_html__( 'Author Thumb', 'masco-hp' ),
						'techza_t_description' => esc_html__( 'Description', 'masco-hp' ),
						'techza_t_author_name' => esc_html__( 'Karen Lynn', 'masco-hp' ),
						'techza_t_author_designation' => esc_html__( 'Founder @ Company', 'masco-hp' ),
					],
				
				],
				'title_field' => '{{{ techza_t_author_name }}}',
			]
		);

		$this->end_controls_section();


		// slider Setting

		$this->start_controls_section(
			't_slider_setting_section',
			[
				'label' => esc_html__( 'Setting', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
					'label' => __('Auto Play?', 'masco-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'masco-hp'),
					'label_off' => __('Hide', 'masco-hp'),
					'return_value' => 'yes',
					'default' => 'no',
			]
		);

		$this->add_control(
            'dots',
            [
                'label' => __('Show Dots?', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'masco-hp'),
                'label_off' => __('Hide', 'masco-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
		$this->end_controls_section();

		// start style parts

		// Image
		$this->start_controls_section(
			'techza_t_author_thumb',
			[
				'label' => esc_html__( 'Image', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			't_author_thumb_width',
			[
				'label' => esc_html__( 'Width', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			't_author_thumb_height_width',
			[
				'label' => esc_html__( 'Height', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 't_author_thumb_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author img',
			]
		);

		$this->add_responsive_control(
			't_author_thumb_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);
		$this->add_responsive_control(
			't_author_thumb_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// end image style

		//Rating
        $this->start_controls_section(
            'rating_style',
            [
                'label'     => __( 'Stars', 'masco' ),
                'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
             
            ]
        );
        $this->add_control(
            'star_size',
            [
                'label'      => __( 'Size', 'masco' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .techza-testimonial-star i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'star_gap',
            [
                'label'      => __( 'Spacing', 'masco' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .techza-testimonial-star i' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'star_color',
            [
                'label'     => __( 'Icon Color', 'masco' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#F0AD4Es',
                'selectors' => [
                    '{{WRAPPER}} .techza-testimonial-star i' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'star_margin',
            [
                'label'      => __( 'Margin', 'masco' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .techza-testimonial-star' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();



		// Title 
		$this->start_controls_section(
			't_title_style',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_title_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data h5' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_title_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data h5',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_title_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data h5',
			]
		);

		$this->add_control(
			't_title_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End Description style

	

		// Description 
		$this->start_controls_section(
			't_des_style',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_des_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_des_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data p',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_des_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-data p',
			]
		);

		$this->add_control(
			't_des_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-data p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End Description style

		//  author 
		$this->start_controls_section(
			't_author_style',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data h6' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data h6',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data h6',
			]
		);

		$this->add_control(
			't_author_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data h6' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style

		// star  author  Designation
		$this->start_controls_section(
			't_author_designation_style',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_designation_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_designation_typography',
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data span',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_designation_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-author-data span',
			]
		);

		$this->add_control(
			't_author_designation_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-author-data span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style


		//  box 
		$this->start_controls_section(
			't_box_style',
			[
				'label' => esc_html__( 'Box', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 't_box_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap',
			]
		);
		$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 't_box_border',
						'label' => esc_html__( 'Border', 'masco-hp' ),
						'selector' => '{{WRAPPER}} .techza-t-infinite-slider-wrap',
					]
				);


	$this->add_control(
			't_box_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			't_box_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-t-infinite-slider-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End box style


		    /*
        * ============================= Dots Style ==============================================
        */
        $this->start_controls_section(
					'dots_navigation',
					[
							'label' => __('Navigation - Dots', 'wybe-hp'),
							'tab' => \Elementor\Controls_Manager::TAB_STYLE,
					]
			);
			$this->start_controls_tabs('_tabs_dots');

			$this->start_controls_tab(
					'_tab_dots_normal',
					[
							'label' => __('Normal', 'wybe-hp'),
					]
			);

			$this->add_control(
					'dots_color',
					[
							'label' => __('Color', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li' => 'background-color: {{VALUE}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_box_width',
					[
							'label' => __('Width', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li' => 'width: {{SIZE}}{{UNIT}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_box_height',
					[
							'label' => __('Height', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li' => 'height: {{SIZE}}{{UNIT}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_margin',
					[
							'label'          => __('Gap Right', 'wybe-hp'),
							'type'           => \Elementor\Controls_Manager::SLIDER,
							'default'        => [
									'unit' => 'px',
							],
							'range'          => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors'      => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li' => 'margin-right: {{SIZE}}{{UNIT}};',
									'body.rtl {{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li' => 'margin-left: {{SIZE}}{{UNIT}};',
							],
					]
			);
			$this->add_responsive_control(
					'dots_min_padding',
					[
							'label'      => __('Margin', 'wybe-hp'),
							'type'       => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => ['px', '%'],
							'selectors'  => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
									'body.rtl {{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}} !important;',
							],
					]
			);
			$this->add_responsive_control(
					'dots_border_radius',
					[
							'label'      => __('Border Radius', 'wybe-hp'),
							'type'       => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => ['px', '%'],
							'selectors'  => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
									'body.rtl {{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
							],
					]
			);
			$this->end_controls_tab();

					// ======================= Dots Active Style =======================================

			$this->start_controls_tab(
					'_tab_dots_active',
					[
							'label' => __('Active', 'wybe-hp'),
					]
			);
			$this->add_control(
					'dots_color_active',
					[
							'label' => __('Active Color', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li.slick-active ' => 'background-color: {{VALUE}}  !important;',
							],
					]
			);

			$this->add_responsive_control(
					'arrow_dots_box_active_width',
					[
							'label' => __('Width', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li.slick-active ' => 'width: {{SIZE}}{{UNIT}} !important;',
							],
					]
			);

			$this->add_responsive_control(
					'arrow_dots_box_active_height',
					[
							'label' => __('Height', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .techza-testimonial-infinite-slider .slick-dots li.slick-active ' => 'height: {{SIZE}}{{UNIT}} !important;',
							],
					]
			);
			$this->end_controls_tab();
			$this->end_controls_tabs();
			$this->end_controls_section();






		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$techza_t_lists = $settings['techza_t_list'];


		 //this code slider option
		 $slider_extraSetting = array(

			'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
			'dots' => (!empty($settings['dots']) && 'yes' === $settings['dots']) ? true : false,

		);

		$jasondecode = wp_json_encode($slider_extraSetting);


		$this->add_render_attribute('techza_t_infinite_slider', 'class', array('techza-testimonial-infinite-slider', 't-style'));
		$this->add_render_attribute('techza_t_infinite_slider', 'data-settings', $jasondecode);
	

	?>
		<section class="section">
			<div <?php echo $this->get_render_attribute_string('techza_t_infinite_slider'); ?>>
				<?php foreach ($techza_t_lists as $techza_t_list) : ?>
			     
	              <div class="techza-t-infinite-slider-wrap">
	              		<?php if ( 'none' != $techza_t_list['star'] ): ?>
						<div class="techza-testimonial-star">
                            <?php for ( $i = 0; $i < $techza_t_list['star']; $i++ ): ?>
                                <i class="fa fa-star"></i>
                            <?php endfor;?>
                        </div>
						<?php endif;?>
	              	<div class="techza-t-infinite-slider-data">
	              		<h5><?php echo esc_html($techza_t_list['techza_t_title']) ?></h5>
	              		<p><?php echo esc_html($techza_t_list['techza_t_description']) ?></p>
	              	</div>
	              	<div class="techza-t-infinite-slider-author-wrap">
	              		<div class="techza-t-infinite-slider-author">
	              			<img src="<?php echo esc_url($techza_t_list['techza_t_author_thumb']['url']) ?>" alt="">
	              		</div>
	              		<div class="techza-t-infinite-slider-author-data">
	              			<h6><?php echo esc_html($techza_t_list['techza_t_author_name']) ?></h6>
	              			<span><?php echo esc_html($techza_t_list['techza_t_author_designation']) ?></span>
	              		</div>
	              	</div>
	              </div>
						
	        	<?php endforeach;?>
	        </div>
		</section>





	<?php
   
 }

}

$widgets_manager->register( new \Techza_Testimonial_Infinite_slider() );