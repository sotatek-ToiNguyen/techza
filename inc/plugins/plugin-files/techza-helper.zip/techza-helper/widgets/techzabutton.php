<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Techza_Button_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'techza_button';
	}

	public function get_title() {
		return esc_html__( 'Techza Button', 'techza-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'techza-addons' ];
	}

	public function get_keywords() {
		return [ 'button', 'techza', 'link' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'next_button_style',
            [
                'label'             => __( 'Team Style', 'techza-hp' ),
                'type'              => \Elementor\Controls_Manager::SELECT,
                'default'           => 'Default',
                'options'           => [
                    'default'   =>   __('Default',    'techza-hp'),
                    'border-style'   =>   __('Border Style',    'techza-hp'),
                    'button-active'   =>   __('Button Active',    'techza-hp'),
                ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
			'techza_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Button Text', 'techza-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'techza-hp' ),
			]
		);

		$this->add_control(
			'techza_button_link',
			[
				'label' => esc_html__( 'Button Url', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'techza-hp' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

		$this->add_responsive_control(
			'button_alignment',
			[
				'label' => esc_html__( 'Alignment', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'techza-hp' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'techza-hp' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'techza-hp' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .techza-button-wraper' => 'text-align: {{VALUE}}',
				],
			]
		);



        $this->end_controls_section();
	
			// End button style

        // start button style
    	$this->start_controls_section(
		'techza_button_style',
		[
			'label' => esc_html__( 'Button', 'techza-hp' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
		);
		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'techza-hp' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'selector' => '{{WRAPPER}} .techza-btn',
			]
		);
		$this->add_control(
			'btn_color',
			[
				'label' => esc_html__( 'Button Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-btn.bg-gray' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'btn_background',
				'label' => esc_html__( 'Background Color', 'techza-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .techza-btn.bg-gray',
			]
		);

		$this->add_responsive_control(
		'btn_width',
		[
			'label' => esc_html__( 'Min Width', 'simple-team-addon' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 1000,
					'step' => 5,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => '%',
				'size' => 100,
			],
			'selectors' => [
				'{{WRAPPER}} .techza-btn' => 'min-width: {{SIZE}}{{UNIT}};',
			],
		]
	);

		$this->add_responsive_control(
			'btn_radius',
			[
				'label' => esc_html__( 'Border Radius', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'btn_margin',
			[
				'label' => esc_html__( 'Margin', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'btn_padding',
			[
				'label' => esc_html__( 'Padding', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'techza-hp' ),
			]
		);

		$this->add_control(
			'btn_hover_color',
			[
				'label' => esc_html__( 'Button Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-btn.bg-gray:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tabs();
		
		$this->end_controls_section();

	}

  protected function render() {
    $settings = $this->get_settings_for_display();

     $next_button_style = $settings['next_button_style'];
     $techza_btn_text = $settings['techza_btn_text'];
     $techza_button_link = $settings['techza_button_link'];
		


		?>

            <div class="techza-button-wraper">
                
                <?php 
                    if('default' == $next_button_style){
                     ?>
                       <a class="techza-btn bg-gray" href="<?php echo esc_url($techza_button_link['url']) ?>">
	                        <?php echo esc_html($techza_btn_text) ?>
	                    </a> 
                    <?php
                    }elseif('button-active' == $next_button_style){
                        ?>
                            <a class="techza-btn bg-gray active" href="<?php echo esc_url($techza_button_link['url']) ?>"><span><?php echo esc_html($techza_btn_text) ?></span>
                            </a>
                        <?php
                    }
                    elseif('border-style' == $next_button_style){
                        ?>
                            <a class="techza-outline-btn" href="<?php echo esc_url($techza_button_link['url']) ?>"><span><?php echo esc_html($techza_btn_text) ?></span>
                            </a>
                        <?php
                    }




                ?>

            
            </div>
            
		
		<?php
   
  }

}

$widgets_manager->register_widget_type( new \Techza_Button_Widget() );