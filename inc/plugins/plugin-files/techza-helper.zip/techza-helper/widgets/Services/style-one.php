<?php
     // from acf
     $txtvalue = get_field( 'text-number' );
     $subheading = get_field( 'sub-heading' );
?>
    <div class="techza-service-widget-item">
        <div class="content-service-wrap">
            <div class="service-thumbnail-wrapper">
                <?php if (!empty( get_post_meta( $idd, 'service_svg_icon', true ) ) ) : ?>
                    <div class="service-thumbnail">
                        <div class="service-thumbnail">
                            <?php
                                $thumb_icon_id = get_post_meta($idd, 'service_svg_icon', true );
                                $thumb_icon_url = wp_get_attachment_image_url( $thumb_icon_id, 'full' );
                            ?>
                            <img src="<?php echo esc_url( $thumb_icon_url) ?>" alt="">

                        </div>
                    </div>
                <?php endif; ?>
                
            </div>
            <!-- <div class="txt-number-wrap">
                <h2 class="txt-number" ><?php echo esc_html( $txtvalue); ?></h2>
            </div> -->
            <div class="service-content">
               <!-- <span class="techza-service-heading d-block"><?php echo esc_html($subheading); ?></span> -->

               <div class="d-block">
               <h3 class="service-title"><a href="<?php echo esc_url( the_permalink()); ?>"><?php echo esc_html(  $title ); ?></a></h3>
               </div>

                <?php
                    echo ( 'yes' == $settings['show_excerpt'] ) ? sprintf( '<p> %s </p>', esc_html( $excerpt ) ) : '';
                ?>

                <?php if ('yes' == $settings['show_readmore']): ?>
                    <div class="service-btn-wrap">
                        <a class="service-btn" href="<?php the_permalink() ?>">
                            <?php if ('before' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                                <span class="icon-before btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                            <?php endif; ?>
                            <?php echo esc_html($settings['readmore_text']); ?>
                            <?php if ('after' == $settings['icon_position'] && !empty($settings['icon']['value'])) : ?>
                                <span class="icon-after btn-icon"><?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?></span>
                            <?php endif; ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
