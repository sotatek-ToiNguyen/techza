<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Techza_Nft_Normal_Card_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'techza_nft_card';
	}

	public function get_title() {
		return esc_html__( 'Techza Nft Card', 'techza-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'techza-addons' ];
	}

	public function get_keywords() {
		return [ 'card' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'techza_nft_card_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'techza_nft_card_title',
			[
				'label' => esc_html__( 'Title', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Default title', 'techza-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'techza-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);


		$this->add_control(
			'techza_nft_color_code',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#0833', 'techza-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'techza-hp' ),
				'label_block' => false,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'techza_nft_card_button',
			[
				'label' => esc_html__( 'Button', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Button', 'techza-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'techza-hp' ),
				'label_block' => false,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'techza_card_button_link',
			[
				'label' => esc_html__( 'Url', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'techza-hp' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);


		$this->end_controls_section();

		
		// Image
		$this->start_controls_section(
			'nft_card_image',
			[
				'label' => esc_html__( 'Image', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'nft_card_iamge_width',
			[
				'label' => esc_html__( 'Width', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .techza-card-thumb img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'nft_card_height_width',
			[
				'label' => esc_html__( 'Height', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .techza-card-thumb img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'nft_card_image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-card-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);
		$this->end_controls_section();
		// end image style

		// Title
		$this->start_controls_section(
			'ft_card_title_style',
			[
				'label' => esc_html__( 'Title', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'nft_card_title_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-card-data h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'nft_card_title_typography',
				'selector' => '{{WRAPPER}} .techza-card-data h3',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'nft_card_title_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-card-data h3',
			]
		);

		$this->add_control(
			'nft_card_title_margin',
			[
				'label' => esc_html__( 'Margin', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-card-data' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End title style

		// nft card Color 
		$this->start_controls_section(
			'nft_card_Color_style',
			[
				'label' => esc_html__( 'Color Code', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'nft_card_Color_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-card-footer-data h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'nft_card_Color_typography',
				'selector' => '{{WRAPPER}} .techza-card-footer-data h4',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'nft_card_Color_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .techza-card-footer-data h4',
			]
		);

		$this->add_control(
			'nft_card_Color_margin',
			[
				'label' => esc_html__( 'Margin', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-card-footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End Color style

		// nft card button 
		$this->start_controls_section(
			'nft_card_button_style',
			[
				'label' => esc_html__( 'Button', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
            'nft_card_button_style_tabs'
    );

      $this->start_controls_tab(
          'nft_card_button_style_normal_tab',
          [
              'label' => __('Normal', 'techza-hp'),
          ]
      );

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'nft_card_btn_typography',
				'selector' => '{{WRAPPER}} .techza-card-btn',
			]
		);


		$this->add_control(
            'nft_card_btn_background',
            [
                'label'     => __('Background Color', 'kinvestor-addons'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techza-card-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );



		$this->add_control(
			'nft_card_btn_color',
			[
				'label' => esc_html__( 'Button Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-card-btn' => 'color: {{VALUE}}',
				],
			]
		);

		  $this->add_responsive_control(
         'nft_card_btn_width',
            [
                'label'      => __('Width', 'techza-hp'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .techza-card-btn'=> 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'nft_card_btn_height',
            [
                'label'      => __('Height', 'techza-hp'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .techza-card-btn' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
				'nft_card_btn_radius',
				[
					'label' => esc_html__( 'Border Radius', 'techza-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .techza-card-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		
		$this->add_control(
			'nft_card_Color_padding',
			[
				'label' => esc_html__( 'Padding', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-card-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		// hover

    $this->start_controls_tab(
        'nft_card_button_style_hover_tab',
        [
            'label' => __('Hover', 'techza-hp'),
        ]
    );


    $this->add_control(
            'nft_card_btn_hover_background',
            [
                'label'     => __('Background Color', 'kinvestor-addons'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techza-card-btn:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
			'nft_card_hover_btn_color',
			[
				'label' => esc_html__( 'Button Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .techza-card-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();
    $this->end_controls_tabs();

		$this->end_controls_section();
		// End card button style

		
		// nft card box 
		$this->start_controls_section(
			'nft_card_box_style',
			[
				'label' => esc_html__( 'Box', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'nft_card_box_background',
				'label' => esc_html__( 'Background', 'techza-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .techza-card-wrap',
			]
		);
		$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'nft_card_box_border',
						'label' => esc_html__( 'Border', 'techza-hp' ),
						'selector' => '{{WRAPPER}} .techza-card-wrap',
					]
				);


	$this->add_control(
			'nft_card_box_radius',
			[
				'label' => esc_html__( 'Border Radius', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-card-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			'nft_card_box_padding',
			[
				'label' => esc_html__( 'Padding', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .techza-card-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End card style


		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$techza_nft_card_thumb = $settings['techza_nft_card_thumb'];
		$techza_nft_card_title = $settings['techza_nft_card_title'];
		$techza_nft_color_code = $settings['techza_nft_color_code'];
		$techza_nft_card_button = $settings['techza_nft_card_button'];
		$techza_card_button_link = $settings['techza_card_button_link'];

	?>

        <div class="techza-card-wrap">
          <div class="techza-card-thumb">
            <img src="<?php echo esc_url($techza_nft_card_thumb['url']) ?>" alt="">
          </div>
          <div class="techza-card-data">
          	  <h3><?php echo esc_html($techza_nft_card_title) ?></h3>
            <div class="techza-card-footer">
              <div class="techza-card-footer-data">
                <h4><?php echo esc_html($techza_nft_color_code) ?></h4>
              </div>
              <a  class="techza-card-btn" href="<?php echo esc_url($techza_card_button_link['url']) ?>">
                 <?php echo esc_html($techza_nft_card_button) ?>
              </a>
            </div>
          </div>
        </div>

	<?php
   
 }

}

$widgets_manager->register_widget_type( new \Techza_Nft_Normal_Card_Widget() );