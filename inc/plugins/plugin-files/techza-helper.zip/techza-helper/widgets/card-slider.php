<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Techza_Card_slider_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Techza_card_slider';
	}

	public function get_title() {
		return esc_html__( 'Techza Card Slider', 'techza-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'techza-addons' ];
	}

	public function get_keywords() {
		return [ 'card', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);



    $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'techza_card_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


		$this->add_control(
			'techza_card_list',
			[
				'label' => esc_html__( 'Repeater List', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'techza_card_thumb' => esc_html__( 'Image', 'techza-hp' ),
	
					],
				
				],
			]
		);


		$this->end_controls_section();

		// slider arrow

		$this->start_controls_section(
			'slider_content_section',
			[
				'label' => esc_html__( 'Arrows', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'arrow_prev_icon',
			[
				'label' => esc_html__( 'Slider Icon Left', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'arrow_next_icon',
			[
				'label' => esc_html__( 'Slider Icon Right', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->end_controls_section();

		// slider Setting

		$this->start_controls_section(
			'slider_setting_section',
			[
				'label' => esc_html__( 'Setting', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
					'label' => __('Auto Play?', 'techza-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'techza-hp'),
					'label_off' => __('Hide', 'techza-hp'),
					'return_value' => 'yes',
					'default' => 'no',
			]
		);
		$this->add_control(
			'arrows',
			[
					'label' => __('Show arrows?', 'techza-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
						'label_on' => __('Show', 'techza-hp'),
						'label_off' => __('Hide', 'techza-hp'),
						'return_value' => 'yes',
						'default' => 'yes',
				]
		);



		$this->end_controls_section();

				// start style parts

			// Image
			$this->start_controls_section(
				'card_image_style',
				[
					'label' => esc_html__( 'Image', 'techza-hp' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);

			$this->add_responsive_control(
				'card_iamge_width',
				[
					'label' => esc_html__( 'Width', 'techza-hp' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
				
					'selectors' => [
						'{{WRAPPER}} .techza-card-slider-item img' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'card_height_width',
				[
					'label' => esc_html__( 'Height', 'techza-hp' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .techza-card-slider-item img' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);

	
			$this->add_control(
				'card_image_border_radius',
				[
					'label' => esc_html__( 'Border Radius', 'techza-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .techza-card-slider-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before'
				]
			);
			$this->end_controls_section();
			// end image style

		

		// slider arrows
		$this->start_controls_section(
			'icon_style_section',
			[
				'label' => esc_html__( 'Arrows', 'techza-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'arrows_style_tabs'
		);

		$this->start_controls_tab(
			'arrow_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'techza-hp' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrow_background',
				'label' => esc_html__( 'Background', 'techza-hp' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .card-slider-arrow button',
			]
		);

		$this->add_control(
			'arrow_fill_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .card-slider-arrow button path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_width',
			[
				'label' => esc_html__( 'Width', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				
				],
		
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'arrows_size',
			[
				'label' => esc_html__( 'Size', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .card-slider-arrow button svg' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'arrows_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'arrows_box_border',
				'label' => esc_html__( 'Border', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .card-slider-arrow button',
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .card-slider-arrow button',
			]
		);

		$this->end_controls_tab();

		// icon hover

		$this->start_controls_tab(
			'arrows_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'techza-hp' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrows_hover_background',
				'label' => esc_html__( 'Background', 'techza-hp' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .card-slider-arrow button:hover',
			]
		);

		$this->add_control(
			'arrows_hover_fill_color',
			[
				'label' => esc_html__( 'Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .card-slider-arrow button:hover path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrows_hover_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'techza-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button:hover path' => 'stroke: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_hover_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'techza-hp' ),
				'selector' => '{{WRAPPER}} .card-slider-arrow button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();



	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$techza_card_list = $settings['techza_card_list'];
		$arrow_prev_icon = $settings['arrow_prev_icon'];
		$arrow_next_icon = $settings['arrow_next_icon'];

		 //this code slider option
		 $slider_extraSetting = array(

			'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
			'arrows' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,

		);

		$jasondecode = wp_json_encode($slider_extraSetting);


		$this->add_render_attribute('techza_card_slider', 'class', array('techza-card-slider', 't-style'));
		$this->add_render_attribute('techza_card_slider', 'data-settings', $jasondecode);

	?>

		    <div <?php echo $this->get_render_attribute_string('techza_card_slider'); ?>>
				<?php foreach ($techza_card_list as $techza_card_lists) : ?>
					<div class="techza-card-slider-item">
						<img src="<?php echo esc_url($techza_card_lists['techza_card_thumb']['url']) ?>" alt="">
					</div>
				<?php endforeach; ?>
		    </div>


			<div class="card-slider-arrow">
				<?php if (!empty($settings['arrow_prev_icon']['value'])) : ?>
						<button type="button" class="slick-prev prev slick-arrow slick-active">
								<?php \Elementor\Icons_Manager::render_icon($arrow_prev_icon, ['aria-hidden' => 'true']);?>
						</button>
				<?php endif; ?>

				<?php if (!empty($settings['arrow_next_icon']['value'])) : ?>
						<button type="button" class="slick-next next slick-arrow ">
								<?php \Elementor\Icons_Manager::render_icon($arrow_next_icon, ['aria-hidden' => 'true']);?>
						</button>
				<?php endif; ?>
			</div>

		<?php
   
  }

}

$widgets_manager->register_widget_type( new \Techza_Card_slider_Widget() );