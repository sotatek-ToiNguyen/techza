(function ($) {

  "use strict";

  /* ---------------------------------------------

  Navigation menu

  --------------------------------------------- */

  // dropdown for mobile
  /* is_exist() */
  jQuery.fn.is_exist = function () {
    return this.length;
  }


  $(window).load(function () {

  })



  /* ---------------------------------------------
  INFINITE SLIDER
  --------------------------------------------- */
  var TechzaTextSlider = function ($scope, $) {
    var wrapper = $scope.find(".techza-text-slider");

    if (wrapper.length === 0)
      return;
    var settings = wrapper.data('settings');

    wrapper.slick({

      rtl: settings['slider_rtl'],
      infinite: true,
      slidesToShow: settings['per_coulmn'],
      slidesToScroll: settings['slide_scroll'],
      arrows: false,
      dots: false,
      autoplay: true,
      autoplaySpeed: 0,
      speed: 10000,
      cssEase: 'linear',
      pauseOnHover: true,
      adaptiveHeight: true,
      responsive: [{
        breakpoint: 1600,
        settings: {
          slidesToShow: settings['per_coulmn'],
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1025,
        settings: {
          slidesToShow: settings['per_coulmn_tablet'],
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: settings['per_coulmn_mobile'],
          slidesToScroll: 1,
        },
      },
      ],
    });
  }



  // card slider
  var TechzaTestimonialInfiniteSlider = function ($scope, $) {
    var wrapper = $scope.find(".techza-testimonial-infinite-slider");
    if (wrapper.length === 0)
      return;
    var settings = wrapper.data('settings');
    wrapper.slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      arrows: false,
      dots: settings['dots'],
      autoplay: settings['autoplay'],
      autoplaySpeed: 2000,
      responsive: [
     
        {
          breakpoint: 1199,
          settings: {
            slidesToShow: 2,
          }
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 575,
          settings: {
            slidesToShow: 1,
            dots: false,
          }
        }

      ]
    });

  }



  // start techza slider one
  var TechzaCardSlider = function ($scope, $) {
    var wrapper = $scope.find(".techza-card-slider");
    if (wrapper.length === 0)
      return;
    var settings = wrapper.data('settings');
    wrapper.slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: settings['arrows'],
      autoplay: settings['autoplay'],
      dots: false,
      prevArrow: $('.prev'),
      nextArrow: $('.next'),
    });

  }


    // start techza hero 
  var TechzaHeroSlider = function ($scope, $) {
    var wrapper = $scope.find(".techza-hero-slider");
    if (wrapper.length === 0)
      return;
    var settings = wrapper.data('settings');
    wrapper.slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: settings['arrows'],
      autoplay: settings['autoplay'],
      dots: false,
      prevArrow: $('.h-prev'),
      nextArrow: $('.h-next'),
    });

  }


      // start techza hero 
  var TechzaTSlider = function ($scope, $) {
    var wrapper = $scope.find(".techza-t-slider");
    if (wrapper.length === 0)
      return;
    var settings = wrapper.data('settings');
    wrapper.slick({
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 1,
      arrows: settings['arrows'],
      autoplay: settings['autoplay'],
      dots: false,
      prevArrow: $('.t-prev'),
      nextArrow: $('.t-next'),
      responsive: [
     
        // {
        //   breakpoint: 1199,
        //   settings: {
        //     slidesToShow: 2,
        //   }
        // },
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          }
        }
 

      ]
    });

  }


        // start techza portfolio 
  var TechzaPortfolioSlider = function ($scope, $) {
    var wrapper = $scope.find(".techza-portfolio-slider");
    if (wrapper.length === 0)
      return;
      var settings = wrapper.data('settings');
      wrapper.slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      arrows: settings['arrows'],
      autoplay: settings['autoplay'],
      dots: false,
      prevArrow: $('.p-prev'),
      nextArrow: $('.p-next'),
      responsive: [
     
        // {
        //   breakpoint: 1199,
        //   settings: {
        //     slidesToShow: 2,
        //   }
        // },
        {
          breakpoint: 1199,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          }
        }
 

      ]
    });

  }




  $(window).on("elementor/frontend/init", function () {
    elementorFrontend.hooks.addAction("frontend/element_ready/Techza_Text_Slider.default", TechzaTextSlider);
    elementorFrontend.hooks.addAction("frontend/element_ready/Techza_Testimonial_Infinite_Slider.default", TechzaTestimonialInfiniteSlider);
    elementorFrontend.hooks.addAction("frontend/element_ready/Techza_card_slider.default", TechzaCardSlider);
    elementorFrontend.hooks.addAction("frontend/element_ready/Techza_Hero_slider.default", TechzaHeroSlider);
    elementorFrontend.hooks.addAction("frontend/element_ready/Techza_T_slider.default", TechzaTSlider);
    elementorFrontend.hooks.addAction("frontend/element_ready/Techza_Portfolio_Slider.default", TechzaPortfolioSlider);
  });

})(jQuery);